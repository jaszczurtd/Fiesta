Adjustometer prototype 1.3

Source: adjustometer.kicad_pcb
SHA-256: bee48b3646626e82928cb6a282061acee8b42c1ae0f7330b22220527bc13dad1

Board: 45 x 36 mm, FR-4, nominal 1.6 mm, 2 layers, nominal 35 um copper.
Minimum copper spacing 0.2 mm; copper-to-edge clearance 0.5 mm.
Vias 0.6 mm / 0.3 mm drill. Four unplated 3.2 mm mounting holes.
Use BOTH adjustometer-PTH.drl and adjustometer-NPTH.drl.
Gerber X2 and Excellon files use millimetres and the same absolute origin.
The .gm1 file is the board outline; .gtp is optional stencil data.
PDF drill maps and CSV BOM are assembly references.

J1 pins 1..5: winding A, winding B, GND, GND, temperature.
Connect pump harness pins 1, 2, 3, 4, 7 to J1 pins 1, 2, 3, 4, 5.
J2 pins 1..5: regulated 5V, GND, SDA, SCL, 12V.
Disconnect external 5V while powering the RP2040-Zero from USB.
Confirm component dimensions, pinouts, power protection and regulator
decoupling against the project README before building the prototype.
The physical assembly has not been tested.
